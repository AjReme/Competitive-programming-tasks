#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int N = inf.readInt(3, 1499, "N");
    inf.readEoln();
    ensuref(N % 2 == 1, "Even N!");
    vector<int> arr(N-1);
    for (int& i : arr) {
    	i = inf.readInt(1, N, "arr");
    	inf.readSpace();
    }
    arr.push_back(inf.readInt(1, N, "arr"));
    inf.readEoln();
    inf.readEof();
    sort(arr.begin(), arr.end());
    ensuref(is_sorted(arr.begin(), arr.end()), "Uncorrect permutation!");
}
