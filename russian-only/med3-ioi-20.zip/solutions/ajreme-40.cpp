#include <bits/stdc++.h>

using namespace std;

int get_N() {
    int N;
    cin >> N;
    return N;
}

int med3(int a, int b, int c) {
    cout << "? " << a << ' ' << b << ' ' << c << endl;
    int ans;
    cin >> ans;
    return ans;
}

int answer(int x) {
    cout << "! " << x << endl;
}

int med_find(int N) {
    vector<int> lst;
    for (int i = 1; i <= N; i++) {
        lst.push_back(i);
    }
    while (lst.size() > 1) {
        vector<int> temp = lst;
        while (temp.size() > 2) {
            int a = *next(temp.begin(), 0);
            int b = *next(temp.begin(), 1);
            int c = *next(temp.begin(), 2);
            temp.erase(find(temp.begin(), temp.end(), med3(a, b, c)));
        }
        int a = *next(temp.begin(), 0);
        int b = *next(temp.begin(), 1);
        lst.erase(find(lst.begin(), lst.end(), a));
        lst.erase(find(lst.begin(), lst.end(), b));
    }
    return *lst.begin();
}

int main() {
    answer(med_find(get_N()));
}
