#!/usr/bin/env bash
echo "No validator to test"
