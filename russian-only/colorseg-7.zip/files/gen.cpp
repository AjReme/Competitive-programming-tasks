#include "testlib.h"
#include <iostream>
#include <vector>

using namespace std;


vector<int> all_different(int n) {
    vector<int> ret;
    for (int i = 1; i <= n; i++) {
        ret.push_back(i);
    }
    shuffle(ret.begin(), ret.end());
    return ret;
}

vector<int> k_different(int n) {
    vector<int> ret, nums;
    int k = rnd.next(1, n);
    for (int i = 1; i <= n; i++) {
        nums.push_back(i);
    }
    shuffle(nums.begin(), nums.end());
    for (int i = 1; i <= n; i++) {
        ret.push_back(nums[rnd.next(1, k)]);
    }
    return ret;
}

vector<int> equal(int n) {
    vector<int> ret;
    int x = rnd.next(1, n);
    for (int i = 1; i <= n; i++) {
        ret.push_back(x);
    }
    return ret;
}

vector<int> sorted(int n) {
    vector<int> ret;
    for (int i = 1; i <= n; i++) {
        ret.push_back(i);
    }
    return ret;
}

vector<int> inv_sorted(int n) {
    vector<int> ret;
    for (int i = n; i >= 1; i--) {
        ret.push_back(i);
    }
    return ret;
}

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 1);

    int test = atoi(argv[1]);
    int type = rnd.next(0, 9);
    vector<int> arr;

    int n;
    if (5 <= test && test <= 23) {
        n = rnd.next(40, 100);
    }
    else if (24 <= test && test <= 43) {
        n = rnd.next(601, 1000);
    }
    else if (44 <= test && test <= 63) {
        n = rnd.next(6001, 10000);
    }
    else if (64 <= test && test <= 83) {
        n = rnd.next(60001, 1000000);
    }
    else {
        n = 1000000;
    }

    println(n);

    if (type == 0) {
        arr = all_different(n);
    }
    else {
        arr = k_different(n);
    }

    println(arr);
}