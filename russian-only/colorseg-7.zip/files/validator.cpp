#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int N = inf.readInt(1, 1000000, "N");
    inf.readEoln();
    for (int i = 0; i < N-1; i++) {
    	inf.readInt(1, N, "arr");
    	inf.readSpace();
    }
    inf.readInt(1, N, "arr");
    inf.readEoln();
    inf.readEof();
}
