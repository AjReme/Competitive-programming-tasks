#include<iostream>
#include<fstream>
#include<cmath>

using namespace std;

long long gran=1000000007;
long long n;

long long gcd(long long l,long long r){
    while(l!=0&&r!=0){
        if(l>r)
            l%=r;
        else r%=l;
    }
    return l+r;
}
long long s(long long r){
    long long x=r,y=r+1,k=2*r+1;
    long long u=6;
    long long f=gcd(u,x);
    u/=f;
    x/=f;
    f=gcd(u,y);
    y/=f;
    u/=f;
    f=gcd(u,k);
    k/=f;
    x%=gran;
    y%=gran;
    x*=y;
    x%=gran;
    k%=gran;
    return (x*k)%gran;
}
long long s(long long l,long long r)
{
    long long x=s(r)-s(l-1);
    if(x<0)
        x+=gran;
    return x;
}
long long bin(long long l,long long r,long long x)
{
    return l;
    if(l==r)
        return l;
    if(l+1==r)
    {
        if(n/l==x)
            return l;
        else return r;
    }
    long long m=(l+r)/2;
   if(n/m>x)
    return bin(m,r,x);
   else bin(l,m,x);
}
long long bin1(long long l,long long r,long long x)
{
    return l;    if(l==r)
        return l;
    if(l+1==r)
    {
        if(n/r==x)
            return r;
        else return l;
    }
    long long m=(l+r)/2;
   if(n/m>=x)
    return bin1(m,r,x);
   else bin1(l,m,x);
}
int main()
{
    cin>>n;

    long long sum=0;
    for(long long i=1;i<=(long long)sqrt(n);i++)
    {
        long long z=i%gran;
        z*=z;
        z%=gran;
        z*=((n/i)%gran);
        z%=gran;
        sum+=z;

        sum%=gran;
    }
    long long l=n,r=n;
    long long k=(long long)sqrt(n);

      for(long long i=1;i<=(long long)sqrt(n);i++)
    {
        l=n/(i+1)+1;
        l=max(l,k+1);

        if(i*i==n)
            continue;

        long long z=s(l,r);
        r=l-1;
        l=r;
        z%=gran;
        z*=(i%gran);
        z%=gran;
        sum+=z;

        sum%=gran;
    }
    cout<<sum;
}
