#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    string N = inf.readToken();
    inf.readEoln();
    inf.readEof();
    N = string(max(size_t(0), 25 - N.size()), '0') + N;
    ensuref(N <= "1000000000000000000000000", "N more than 10^24!");
}
