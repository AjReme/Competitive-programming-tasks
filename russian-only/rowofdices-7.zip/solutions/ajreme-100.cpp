#include<bits/stdc++.h>
#define int long double
using namespace std;

map<int,long long>a;
vector<long long>pr;
vector<long long>ok;
vector<int>f;
long long d[200];
int n;
void calc(long long x)
{

    long long e=x;

    int sum=0;
    long long kol=0;
    while(x>1)
    {
//cout<<f[x]<<' '<<x<<endl;
    kol++;
        sum+=f[x]-1;
        if(sum>79)
            return;
        d[kol-1]=f[x];
        x/=f[x];
    }
    sort(d,d+kol);


    if(sum>79)
        return;




    int q=1;
    for(long long i=0;i<kol;i++)
    {

        for(long long j=0;j<d[i]-1;j++)
            {q*=pr[kol-i-1]; if(q>n+85)
        return;}

    }

        x=e;
        //cout<<x<<endl;

    for(long long i=1;i*i<=x;i++)
        if(x%i==0)
    {
        ok[i]=1;
        ok[x/i]=1;
    }
}
 main()
{

    long long i=2;
    vector<int>e(1000000);
    ok.resize(2000000);
    f.resize(2000000);
    ok[1]=1;
    e[1]=1;

    for(int i=2;i<1000000;i++)
        if(e[i]==0)
        for(int j=2*i;j<1000000;j+=i)
        e[j]=1;
    for(int i=2;i<2000000;i++)
    if(f[i]==0)
        for(int j=i;j<2000000;j+=i)
        f[j]=i;
    for(int i=1;i<1000000;i++)
        if(e[i]==0)
        pr.push_back(i);
        string s;
        cin>>s;
        for(int i=0;i<s.size();i++)
        {
            n*=10;
            n+=s[i]-48;
        }



    for(int j=0;j<1000000;j++)
        if(6*j+1<2000000)
        calc(6*j+1);


      //  return 0;
    a.insert(make_pair(1,1));


    long long kol=0;

    for(long long i=0;i<pr.size();i++)
    {

    //cout<<i<<endl;

        int x=1;
        for(long long j=0;j<4;j++)
            x*=pr[i];


        if(x>n)
            break;

            long long f=5;
              vector<int>b;
              vector<long long>c;

        while(x<=n)
        {

            for(auto j:a)
                if((j.first*x)<=n)
            {


                 if(ok[j.second*f]){
                if(j.first*x*pr[i]*pr[i]>n||j.first*x*pr[i]*pr[i]*pr[i]*pr[i]>n)
                {
                    if((j.second*f)%6==1)
                        kol++;
                }
                else
                {b.push_back(j.first*x);

                c.push_back(j.second*f);}

            }
            }
            else break;

            f+=2;
            x*=pr[i]*pr[i];

        }
        for(int i=0;i<b.size();i++)

        a.insert(make_pair(b[i],c[i]));
    }

   for(auto i:a)
        if(i.second%6==1)
        {kol++;}
    cout<<kol;


   // cout<<pr.back()<<endl;

}

