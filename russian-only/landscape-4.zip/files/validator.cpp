#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    int N = inf.readInt(1, 100000, "N");
    inf.readSpace();
    int X = inf.readInt(0, 100000000, "X");
    inf.readSpace();
    int Y = inf.readInt(0, 100000000, "Y");
    inf.readSpace();
    int Z = inf.readInt(0, 1000, "Z");
    inf.readEoln();
    for (int i = 0; i < N; i++) {
    	int A = inf.readInt(0, 10, "Ai");
    	inf.readSpace();
    	int B = inf.readInt(0, 10, "Bi");
    	inf.readEoln();
    }
    inf.readEof();
}
